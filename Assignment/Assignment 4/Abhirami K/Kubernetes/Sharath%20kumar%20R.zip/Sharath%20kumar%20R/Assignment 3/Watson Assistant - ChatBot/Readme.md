Link - Watson Assistant: TrialBot

https://web-chat.global.assistant.watson.appdomain.cloud/preview.html?backgroundImageURL=https%3A%2F%2Fau-syd.assistant.watson.cloud.ibm.com%2Fpublic%2Fimages%2Fupx-5d584591-8035-4368-a77a-c1819f587fe5%3A%3A6b9f3f1a-b34d-4bc7-996c-86edac11853d&integrationID=570c7aea-28ec-4a7a-833e-c66d7a9f8f89&region=au-syd&serviceInstanceID=5d584591-8035-4368-a77a-c1819f587fe5

<img width="1440" alt="image" src="https://user-images.githubusercontent.com/92638245/197332564-ebd1ac33-243e-44f1-9cd9-53efcb00936b.png">

